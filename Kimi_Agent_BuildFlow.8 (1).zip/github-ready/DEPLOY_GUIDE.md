# دليل النشر على GitHub Pages 📘

## 🎯 الهدف
نشر موقع BuildFlow Designer على GitHub Pages مجاناً

---

## 📋 المتطلبات
- حساب GitHub مجاني
- ملفات الموقع (موجودة في هذا المجلد)

---

## 🚀 الخطوات بالتفصيل

### ✅ الخطوة 1: إنشاء حساب GitHub
1. اذهب إلى https://github.com
2. انقر **Sign up**
3. أكمل التسجيل (اسم المستخدم + إيميل + كلمة مرور)

---

### ✅ الخطوة 2: إنشاء مستودع جديد
1. سجل دخولك في GitHub
2. انقر على الزر **+** في الأعلى
3. اختر **New repository**
4. املأ البيانات:
   - **Repository name**: `buildflow-designer`
   - **Description**: `محرر تصميم تفاعلي`
   - **Public** ✓ (يجب أن يكون عام)
   - **Add a README file** ☐ (لا تحتاجه)
5. انقر **Create repository**

---

### ✅ الخطوة 3: رفع الملفات

#### الطريقة 1: من الموقع (أسهل)

1. في المستودع الجديد، انقر على:
   ```
   uploading an existing file
   ```

2. اسحب وأفلت هذه الملفات:
   ```
   index.html
   assets/
   ```

3. في الأسفل، اكتب:
   - **Commit message**: `Initial commit`
   - انقر **Commit changes**

#### الطريقة 2: من سطح المكتب

1. افتح Terminal أو Command Prompt
2. اكتب:
```bash
cd Desktop
mkdir buildflow-designer
cd buildflow-designer
```

3. انسخ ملفات `dist/` إلى هذا المجلد

4. اكتب:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/buildflow-designer.git
git push -u origin main
```

---

### ✅ الخطوة 4: تفعيل GitHub Pages

1. في المستودع، انقر على **Settings**
   
   ![Settings](https://i.imgur.com/Settings.png)

2. في القائمة اليسرى، انقر على **Pages**

3. في قسم **Source**:
   - اختر: **Deploy from a branch**
   - الفرع: `main`
   - المجلد: `/(root)`

4. انقر **Save**

5. انتظر 2-5 دقائق

---

### ✅ الخطوة 5: زيارة الموقع

بعد 5 دقائق، سيكون موقعك جاهز على:

```
https://yourusername.github.io/buildflow-designer
```

استبدل `yourusername` باسم مستخدم GitHub الخاص بك

---

## 🔄 تحديث الموقع

عندما تريد تحديث الموقع:

1. عدل الكود في مشروعك المحلي
2. شغل: `npm run build`
3. انسخ ملفات `dist/` الجديدة
4. ارفعها على GitHub (استبدل الملفات القديمة)
5. انتظر 2-5 دقائق

---

## ❌ حل المشاكل الشائعة

### المشكلة 1: الموقع لا يظهر
**الحل**: تأكد أنك اخترت `main` وليس `master`

### المشكلة 2: الصفحة بيضاء
**الحل**: تأكد من رفع مجلد `assets/` مع `index.html`

### المشكلة 3: خطأ 404
**الحل**: انتظر 5 دقائق أخرى أو تأكد من اسم المستودع

---

## 📞 هل تحتاج مساعدة؟

إذا واجهت أي مشكلة، راسلني!

---

**بالتوفيق! 🎉**
