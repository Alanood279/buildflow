# BuildFlow Designer 🎨

محرر تصميم تفاعلي احترافي مشابه لـ Canva - صمم الصور والملصقات والتصاميم بسهولة!

![BuildFlow Designer](https://img.shields.io/badge/BuildFlow-Designer-blue?style=for-the-badge)
![React](https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?style=for-the-badge&logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-06B6D4?style=for-the-badge&logo=tailwindcss)

## 🌐 الموقع المباشر

**[https://yourusername.github.io/buildflow-designer](https://yourusername.github.io/buildflow-designer)**

---

## ✨ المميزات

### 🎨 أدوات التصميم
- ✅ **قوالب جاهزة** - اختر من مجموعة قوالب احترافية
- ✅ **أشكال متنوعة** - مربعات، دوائر، مثلثات، نجوم، قلوب
- ✅ **نصوص قابلة للتحرير** - أضف وحرر النصوص بسهولة
- ✅ **معرض صور** - صور جاهزة للاستخدام
- ✅ **رفع ملفات** - ارفع صورك الخاصة

### 🖱️ التفاعل
- ✅ **سحب وإفلات** - حرك العناصر بسهولة
- ✅ **تغيير الحجم** - تكبير/تصغير لوحة التصميم (10% - 200%)
- ✅ **تراجع/إعادة** - Undo/Redo للتعديلات
- ✅ **معاينة مباشرة** - شاهد تصميمك قبل النشر

### 🎨 الواجهة
- ✅ **تصميم عصري** - واجهة داكنة أنيقة
- ✅ **دعم العربية** - واجهة عربية كاملة (RTL)
- ✅ **سريع وخفيف** - أداء عالي وسريع

---

## 🛠️ التقنيات المستخدمة

| التقنية | الاستخدام |
|---------|-----------|
| **React 18** | مكتبة الواجهات الأمامية |
| **TypeScript** | لغة البرمجة |
| **Tailwind CSS** | تصميم الواجهة |
| **shadcn/ui** | مكونات واجهة المستخدم |
| **react-dnd** | السحب والإفلات |
| **Lucide Icons** | الأيقونات |

---

## 📁 هيكل المشروع

```
buildflow-designer/
├── index.html          # الصفحة الرئيسية
├── assets/
│   ├── index-XXXXX.js  # كود JavaScript
│   └── index-XXXXX.css # ملفات CSS
└── README.md           # هذا الملف
```

---

## 🚀 طريقة الرفع على GitHub Pages

### الخطوة 1: إنشاء مستودع جديد
1. اذهب إلى [GitHub](https://github.com)
2. انقر على **New Repository**
3. اسم المستودع: `buildflow-designer`
4. اجعله **Public**
5. انقر **Create repository**

### الخطوة 2: رفع الملفات

#### الطريقة الأولى: باستخدام GitHub Website
1. في المستودع الجديد، انقر على **uploading an existing file**
2. اسحب وأفلت جميع الملفات من مجلد `dist/`
3. اكتب رسالة: `Initial commit`
4. انقر **Commit changes**

#### الطريقة الثانية: باستخدام Git
```bash
# في جهازك
mkdir buildflow-designer
cd buildflow-designer

# انسخ ملفات dist هنا
# ثم:
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/buildflow-designer.git
git push -u origin main
```

### الخطوة 3: تفعيل GitHub Pages
1. في المستودع، اذهب إلى **Settings**
2. انقر على **Pages** من القائمة اليسرى
3. في **Source**، اختر **Deploy from a branch**
4. اختر الفرع: `main`
5. المجلد: `/(root)`
6. انقر **Save**

### الخطوة 4: انتظر التفعيل
- سيتم نشر الموقع خلال **2-5 دقائق**
- الرابط: `https://yourusername.github.io/buildflow-designer`

---

## 🔄 تحديث الموقع

عندما تعدل الكود:

```bash
# 1. عدل الكود في src/

# 2. بناء المشروع
npm run build

# 3. انسخ ملفات dist/ جديدة

# 4. ارفعها على GitHub
```

---

## 📝 ملاحظات مهمة

| ⚠️ تنبيه | الحل |
|----------|------|
| لا ترفع مجلد `src/` | ارفع فقط محتويات `dist/` |
| لا ترفع `node_modules/` | غير مطلوب للنشر |
| تأكد من المسارات | يجب أن يكون `index.html` في الجذر |

---

## 🎯 الخطوات السريعة (ملخص)

```
1. أنشئ مستودع على GitHub
2. ارفع ملفات dist/ فقط
3. Settings → Pages → main → Save
4. انتظر 5 دقائق
5. جاهز! 🎉
```

---

## 📞 الدعم

إذا واجهت أي مشكلة، تواصل معي!

---

## 📄 الترخيص

MIT License - حر في الاستخدام والتعديل

---

**صنع بـ ❤️ بواسطة BuildFlow**
