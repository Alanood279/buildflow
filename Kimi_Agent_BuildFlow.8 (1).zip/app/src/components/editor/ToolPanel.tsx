import { 
  Type, 
  Image, 
  Search,
  Square,
  Circle,
  Triangle,
  Star,
  Heart
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ToolPanelProps {
  activeTool: string;
  onAddElement: (type: 'text' | 'image' | 'shape') => void;
}

const templates = [
  { id: 1, name: 'ملصق اجتماعي', color: 'bg-gradient-to-br from-pink-500 to-orange-400' },
  { id: 2, name: 'ملصق اجتماعي', color: 'bg-gradient-to-br from-blue-500 to-cyan-400' },
  { id: 3, name: 'ملصق اجتماعي', color: 'bg-gradient-to-br from-purple-500 to-pink-400' },
  { id: 4, name: 'ملصق اجتماعي', color: 'bg-gradient-to-br from-green-500 to-teal-400' },
  { id: 5, name: 'ملصق اجتماعي', color: 'bg-gradient-to-br from-red-500 to-pink-400' },
  { id: 6, name: 'ملصق اجتماعي', color: 'bg-gradient-to-br from-indigo-500 to-purple-400' },
];

const shapes = [
  { id: 'square', icon: Square, label: 'مربع' },
  { id: 'circle', icon: Circle, label: 'دائرة' },
  { id: 'triangle', icon: Triangle, label: 'مثلث' },
  { id: 'star', icon: Star, label: 'نجمة' },
  { id: 'heart', icon: Heart, label: 'قلب' },
];

export function ToolPanel({ activeTool, onAddElement }: ToolPanelProps) {
  const renderContent = () => {
    switch (activeTool) {
      case 'templates':
        return (
          <div className="p-4">
            <h3 className="text-white font-semibold mb-4">قوالب التصميم</h3>
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input 
                placeholder="البحث في القوالب..."
                className="pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              {templates.map((template) => (
                <div 
                  key={template.id}
                  className={`${template.color} h-24 rounded-lg cursor-pointer hover:scale-105 transition-transform flex items-end p-2`}
                >
                  <span className="text-white text-xs font-medium">{template.name}</span>
                </div>
              ))}
            </div>
          </div>
        );

      case 'elements':
        return (
          <div className="p-4">
            <h3 className="text-white font-semibold mb-4">الأشكال</h3>
            <div className="grid grid-cols-3 gap-3">
              {shapes.map((shape) => {
                const Icon = shape.icon;
                return (
                  <button
                    key={shape.id}
                    onClick={() => onAddElement('shape')}
                    className="flex flex-col items-center gap-2 p-4 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors"
                  >
                    <Icon className="w-8 h-8 text-gray-300" />
                    <span className="text-gray-400 text-xs">{shape.label}</span>
                  </button>
                );
              })}
            </div>
            
            <h3 className="text-white font-semibold mb-4 mt-6">خطوط</h3>
            <div className="space-y-2">
              <div className="h-px bg-gray-600 w-full" />
              <div className="h-0.5 bg-gray-600 w-full" />
              <div className="h-1 bg-gray-600 w-full" />
              <div className="h-2 bg-gray-600 w-full rounded-full" />
            </div>
          </div>
        );

      case 'text':
        return (
          <div className="p-4">
            <h3 className="text-white font-semibold mb-4">إضافة نص</h3>
            <Button 
              onClick={() => onAddElement('text')}
              className="w-full mb-4 bg-blue-600 hover:bg-blue-700"
            >
              <Type className="w-4 h-4 ml-2" />
              إضافة نص جديد
            </Button>
            
            <h3 className="text-white font-semibold mb-4">أنماط النص</h3>
            <div className="space-y-3">
              <div className="p-3 bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-700">
                <p className="text-2xl text-white font-bold">عنوان كبير</p>
              </div>
              <div className="p-3 bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-700">
                <p className="text-lg text-white">عنوان فرعي</p>
              </div>
              <div className="p-3 bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-700">
                <p className="text-sm text-gray-300">نص عادي</p>
              </div>
            </div>
          </div>
        );

      case 'images':
        return (
          <div className="p-4">
            <h3 className="text-white font-semibold mb-4">معرض الصور</h3>
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input 
                placeholder="البحث في الصور..."
                className="pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
              />
            </div>
            <Button 
              onClick={() => onAddElement('image')}
              className="w-full mb-4 bg-blue-600 hover:bg-blue-700"
            >
              <Image className="w-4 h-4 ml-2" />
              إضافة صورة
            </Button>
            <div className="grid grid-cols-2 gap-2">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div 
                  key={i}
                  className="aspect-square bg-gray-700 rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-600"
                >
                  <Image className="w-8 h-8 text-gray-500" />
                </div>
              ))}
            </div>
          </div>
        );

      case 'brand':
        return (
          <div className="p-4">
            <div className="flex items-center gap-2 mb-4">
              <span className="text-yellow-400 text-2xl">👑</span>
              <h3 className="text-white font-semibold">العلامة التجارية</h3>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              قم بترقية حسابك للوصول إلى ميزات العلامة التجارية
            </p>
            <Button className="w-full bg-gradient-to-r from-yellow-500 to-orange-500">
              ترقية الآن
            </Button>
          </div>
        );

      case 'uploads':
        return (
          <div className="p-4">
            <h3 className="text-white font-semibold mb-4">التحميلات</h3>
            <Button className="w-full mb-4 bg-blue-600 hover:bg-blue-700">
              رفع ملف
            </Button>
            <p className="text-gray-400 text-sm text-center">
              لم تقم بتحميل أي ملفات بعد
            </p>
          </div>
        );

      case 'tools':
        return (
          <div className="p-4">
            <h3 className="text-white font-semibold mb-4">الأدوات</h3>
            <div className="space-y-2">
              <Button variant="ghost" className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-800">
                🎨 لوحة الألوان
              </Button>
              <Button variant="ghost" className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-800">
                📐 المسطرة
              </Button>
              <Button variant="ghost" className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-800">
                🖼️ قص الصورة
              </Button>
              <Button variant="ghost" className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-800">
                ✨ تأثيرات
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="w-72 bg-[#1a1a2e] border-l border-gray-800">
      <ScrollArea className="h-[calc(100vh-14rem)]">
        {renderContent()}
      </ScrollArea>
    </div>
  );
}
