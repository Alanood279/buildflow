import { Minus, Plus, Grid3X3, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

interface BottomBarProps {
  zoom: number;
  onZoomChange: (zoom: number) => void;
}

export function BottomBar({ zoom, onZoomChange }: BottomBarProps) {
  return (
    <div className="h-14 bg-[#0f0f1a] flex items-center justify-between px-4 border-t border-gray-800">
      {/* Left - Pages */}
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon"
          className="text-gray-400 hover:text-white hover:bg-white/10"
        >
          <Grid3X3 className="w-5 h-5" />
        </Button>
        
        <div className="flex items-center gap-2">
          <span className="text-white text-sm">الصفحات</span>
          <Layers className="w-5 h-5 text-gray-400" />
        </div>
        
        <div className="flex items-center gap-2">
          <div className="w-20 h-12 bg-white rounded border-2 border-blue-500 flex items-center justify-center">
            <span className="text-gray-800 text-lg">1</span>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            className="w-8 h-8 bg-gray-700 text-white hover:bg-gray-600"
          >
            <Plus className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="w-8 h-8 bg-gray-700 text-white hover:bg-gray-600"
          >
            <Minus className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Center - Zoom */}
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon"
          className="text-gray-400 hover:text-white hover:bg-white/10"
          onClick={() => onZoomChange(Math.max(10, zoom - 10))}
        >
          <Minus className="w-4 h-4" />
        </Button>
        
        <span className="text-white text-sm w-12 text-center">{zoom}%</span>
        
        <Button 
          variant="ghost" 
          size="icon"
          className="text-gray-400 hover:text-white hover:bg-white/10"
          onClick={() => onZoomChange(Math.min(200, zoom + 10))}
        >
          <Plus className="w-4 h-4" />
        </Button>
        
        <div className="w-32">
          <Slider
            value={[zoom]}
            onValueChange={(value) => onZoomChange(value[0])}
            min={10}
            max={200}
            step={5}
            className="w-full"
          />
        </div>
      </div>

      {/* Right - Notes */}
      <div className="flex items-center gap-2">
        <Button 
          variant="ghost" 
          className="text-gray-400 hover:text-white hover:bg-white/10 flex items-center gap-2"
        >
          <span>ملاحظات</span>
        </Button>
      </div>
    </div>
  );
}
