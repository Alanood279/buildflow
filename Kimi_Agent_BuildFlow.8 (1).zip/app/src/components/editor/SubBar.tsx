import { MessageSquarePlus, Crown, Circle } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function SubBar() {
  return (
    <div className="h-12 bg-[#1a1a2e] flex items-center justify-center gap-4 px-4 border-b border-gray-800">
      <Button 
        variant="ghost" 
        className="text-white hover:bg-white/10 flex items-center gap-2"
      >
        <MessageSquarePlus className="w-5 h-5" />
        <span>طرح الأسئلة على BuildFlow</span>
      </Button>
      
      <Button 
        variant="ghost" 
        className="text-white hover:bg-white/10 flex items-center gap-2"
      >
        <Crown className="w-4 h-4 text-yellow-400" />
        <span>خلفية سحرية</span>
      </Button>
      
      <Button 
        variant="ghost" 
        className="text-white hover:bg-white/10 flex items-center gap-2"
      >
        <Circle className="w-5 h-5" />
        <span>الوضع</span>
      </Button>
    </div>
  );
}
