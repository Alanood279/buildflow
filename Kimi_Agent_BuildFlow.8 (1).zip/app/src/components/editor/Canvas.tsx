import { useState, useRef } from 'react';
import { Image } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CanvasElement {
  id: string;
  type: 'text' | 'image' | 'shape';
  x: number;
  y: number;
  width: number;
  height: number;
  content?: string;
  src?: string;
  style?: React.CSSProperties;
}

interface CanvasProps {
  zoom: number;
}

export function Canvas({ zoom }: CanvasProps) {
  const [elements, setElements] = useState<CanvasElement[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const element = elements.find(el => el.id === id);
    if (!element) return;

    setSelectedId(id);
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - element.x,
      y: e.clientY - element.y
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !selectedId) return;

    setElements(prev => prev.map(el => 
      el.id === selectedId 
        ? { ...el, x: e.clientX - dragOffset.x, y: e.clientY - dragOffset.y }
        : el
    ));
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleCanvasClick = () => {
    setSelectedId(null);
  };

  return (
    <div 
      ref={canvasRef}
      className="flex-1 bg-[#1a1a2e] relative overflow-hidden flex items-center justify-center"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onClick={handleCanvasClick}
    >
      {/* Canvas Page */}
      <div 
        className="bg-white shadow-2xl relative transition-transform"
        style={{
          width: '600px',
          height: '800px',
          transform: `scale(${zoom / 100})`,
        }}
      >
        {/* Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(to right, #ccc 1px, transparent 1px),
              linear-gradient(to bottom, #ccc 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px'
          }}
        />

        {/* Empty State */}
        {elements.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-gray-400">
              <div className="w-16 h-16 border-2 border-dashed border-gray-300 rounded-lg mx-auto mb-4 flex items-center justify-center">
                <span className="text-2xl">+</span>
              </div>
              <p className="text-sm">اختر أداة من الشريط الجانبي للبدء</p>
            </div>
          </div>
        )}

        {/* Elements */}
        {elements.map((element) => (
          <div
            key={element.id}
            className={cn(
              "absolute cursor-move",
              selectedId === element.id && "ring-2 ring-blue-500"
            )}
            style={{
              left: element.x,
              top: element.y,
              width: element.width,
              height: element.height,
              ...element.style
            }}
            onMouseDown={(e) => handleMouseDown(e, element.id)}
          >
            {element.type === 'text' && (
              <div 
                contentEditable
                className="w-full h-full p-2 outline-none"
                suppressContentEditableWarning
              >
                {element.content}
              </div>
            )}
            {element.type === 'shape' && (
              <div className="w-full h-full rounded-lg" style={{ backgroundColor: element.style?.backgroundColor }} />
            )}
            {element.type === 'image' && (
              <div className="w-full h-full bg-gray-200 rounded-lg flex items-center justify-center">
                <Image className="w-8 h-8 text-gray-400" />
              </div>
            )}
            
            {/* Resize Handles */}
            {selectedId === element.id && (
              <>
                <div className="absolute -top-1 -left-1 w-2 h-2 bg-blue-500 rounded-full" />
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full" />
                <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-blue-500 rounded-full" />
                <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-blue-500 rounded-full" />
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
