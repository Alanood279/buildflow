import { 
  LayoutTemplate, 
  Shapes, 
  Type, 
  Image, 
  Crown,
  Cloud,
  PenTool
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SidebarProps {
  activeTool: string;
  onToolChange: (tool: string) => void;
}

const tools = [
  { id: 'templates', label: 'قوالب', icon: LayoutTemplate },
  { id: 'elements', label: 'العناصر', icon: Shapes },
  { id: 'text', label: 'النص', icon: Type },
  { id: 'images', label: 'معرض الصور', icon: Image },
  { id: 'brand', label: 'العلامة التجارية', icon: Crown, premium: true },
  { id: 'uploads', label: 'التحميلات', icon: Cloud },
  { id: 'tools', label: 'الأدوات', icon: PenTool },
];

export function Sidebar({ activeTool, onToolChange }: SidebarProps) {
  return (
    <div className="w-20 bg-[#0f0f1a] flex flex-col items-center py-4 gap-2 border-l border-gray-800">
      {tools.map((tool) => {
        const Icon = tool.icon;
        const isActive = activeTool === tool.id;
        
        return (
          <button
            key={tool.id}
            onClick={() => onToolChange(tool.id)}
            className={cn(
              "w-16 h-16 rounded-xl flex flex-col items-center justify-center gap-1 transition-all",
              isActive 
                ? "bg-white/10 text-white" 
                : "text-gray-400 hover:text-white hover:bg-white/5"
            )}
          >
            <div className="relative">
              <Icon className="w-6 h-6" />
              {tool.premium && (
                <Crown className="w-3 h-3 text-yellow-400 absolute -top-1 -right-1" />
              )}
            </div>
            <span className="text-[10px] text-center leading-tight">{tool.label}</span>
          </button>
        );
      })}
    </div>
  );
}
