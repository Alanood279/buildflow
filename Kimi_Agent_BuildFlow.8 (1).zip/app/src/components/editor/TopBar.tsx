import { 
  Home, 
  Maximize2, 
  Pencil, 
  ChevronDown, 
  Undo2, 
  Redo2, 
  MessageCircle, 
  CheckCircle2, 
  Eye, 
  Globe,
  Upload,
  Share2
} from 'lucide-react';
import { Button } from '@/components/ui/button';

export function TopBar() {
  return (
    <div className="h-14 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 flex items-center justify-between px-4 text-white">
      {/* Left Section */}
      <div className="flex items-center gap-2">
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20 flex items-center gap-2 bg-white/10"
        >
          <Share2 className="w-4 h-4" />
          <span>مشاركة</span>
          <Upload className="w-4 h-4" />
        </Button>
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20 flex items-center gap-2"
        >
          <Globe className="w-4 h-4" />
          <span>نشر الموقع الإلكتروني</span>
        </Button>
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20 flex items-center gap-2"
        >
          <Eye className="w-4 h-4" />
          <span>معاينة</span>
        </Button>
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20"
        >
          <MessageCircle className="w-5 h-5" />
        </Button>
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20"
        >
          <CheckCircle2 className="w-5 h-5" />
        </Button>
        
        <div className="w-px h-6 bg-white/30 mx-2" />
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20"
        >
          <Undo2 className="w-5 h-5" />
        </Button>
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20"
        >
          <Redo2 className="w-5 h-5" />
        </Button>
        
        <div className="w-px h-6 bg-white/30 mx-2" />
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20 flex items-center gap-2"
        >
          <span>التعديل</span>
          <ChevronDown className="w-4 h-4" />
          <Pencil className="w-4 h-4" />
        </Button>
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20 flex items-center gap-2"
        >
          <span>تغيير الحجم</span>
          <Maximize2 className="w-4 h-4" />
        </Button>
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20"
        >
          <span>ملف</span>
        </Button>
        
        <Button 
          variant="ghost" 
          className="text-white hover:bg-white/20"
        >
          <Home className="w-5 h-5" />
        </Button>
      </div>

      {/* Right Section - Logo */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
          <span className="font-bold text-lg">B</span>
        </div>
      </div>
    </div>
  );
}
