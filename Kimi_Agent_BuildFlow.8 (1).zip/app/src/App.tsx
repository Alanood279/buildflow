import { useState, useCallback } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { TopBar } from './components/editor/TopBar';
import { SubBar } from './components/editor/SubBar';
import { Sidebar } from './components/editor/Sidebar';
import { ToolPanel } from './components/editor/ToolPanel';
import { Canvas } from './components/editor/Canvas';
import { BottomBar } from './components/editor/BottomBar';
import './App.css';

function App() {
  const [activeTool, setActiveTool] = useState('templates');
  const [zoom, setZoom] = useState(44);

  const handleToolChange = useCallback((tool: string) => {
    setActiveTool(tool);
  }, []);

  const handleZoomChange = useCallback((newZoom: number) => {
    setZoom(newZoom);
  }, []);

  const handleAddElement = useCallback((type: 'text' | 'image' | 'shape') => {
    // This will be implemented in Canvas component
    console.log('Adding element:', type);
  }, []);

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-screen flex flex-col bg-[#0f0f1a] overflow-hidden">
        {/* Top Bar */}
        <TopBar />
        
        {/* Sub Bar */}
        <SubBar />
        
        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar */}
          <Sidebar 
            activeTool={activeTool} 
            onToolChange={handleToolChange} 
          />
          
          {/* Tool Panel */}
          <ToolPanel 
            activeTool={activeTool}
            onAddElement={handleAddElement}
          />
          
          {/* Canvas */}
          <Canvas zoom={zoom} />
        </div>
        
        {/* Bottom Bar */}
        <BottomBar 
          zoom={zoom} 
          onZoomChange={handleZoomChange} 
        />
      </div>
    </DndProvider>
  );
}

export default App;
